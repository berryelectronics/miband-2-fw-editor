app_icons:
    1: Animated Phone ringing (missing)
    2: Animated Call Icon (missing)
    3: Email
    4: Facebook
    5: Call (no animation)
    6: Generic App
    7: Message Heart (missing)
    8: Mi Fit
    9: MiTalk
    10: Facebook Messenger
    11: Tencent QQ
    12: Message App Icon (missing)
    13: Snapchat
    14: Taobao
    15: Google Hangouts
    16: Twitter
    17: Weird Message Icon (missing)
    18: Weibo
    19: Whatsapp
    20: Instagram
    21: VKontakte
    22: Pokemon Go
    23: Skype
    24: Telegram
    25: Calendar
    26: Japanese Mail thing ???
    27: Midong
    28: Momo
    29: Qianniu
    30: Baidu Tieba
    31: Alipay
    32: QZone
    33: Xianyu
    34: JD.com
    35: DingTalk
    36: Line
    37: Talk
    38: Mi
    39: Other Message with Star
    40: YouTube

medium_number:
    0-9

small_text:
    a
    b
    c
    d
    e
    g
    h
    i
    l
    n
    o
    p
    r
    t
    u
    v
    y
    A
    D
    F
    J
    M
    N
    O
    S
    T
    W
