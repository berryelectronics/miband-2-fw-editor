Mi-Band-2-Firmware-Editor

This project is there to modify the original Mi Band 2 Firmware so that the user
can modify certain aspects of their fitness tracker, making it more customizable
and hackable.

Currently it allows for the following modifications:
 * Editing nearly all notification icons (32 out of 36)
 * Edit the medium-sized numbers used to display the time
 * Edit the small text used to display the current date (not all small characters available)

Features of the software:
 * Built-in mini-editor for the fonts and icons
 * Reads the data from a imported firmware file, which means you can "save" your changes and use them later

Currently the following Mi Band 2 Firmware versions are supported:
 * 1.0.54 !!!

Yeah i know it isnt really beautiful or simple to understand or making it easy
to edit the files but it right now it works for what it should do.

Images: 

https://i.imgur.com/oKdj1tH.png

Credits:

Thanks to SirStefan (xda) for the information about the small font data.

https://forum.xda-developers.com/general/accessories/miband2-scheme-translation-date-to-t3690142/