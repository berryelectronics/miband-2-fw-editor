Mi-Band-2-Firmware-Editor

Changelog:

Version 0.2.0:
* Added different sized Brush options (rectangular Brush)
* Changed Brush behavior to be fixed instead of just flipping every pixel it crosses
* Added Border around pixels that can be affected by the Brush when its hovering

Version 0.2.1:
* CRITICAL: Fixed potential overwriting of other firmware data when saving something from the editor!!!
* Fixed redrawing and scanning of the editor when the firmware gets loaded the first time